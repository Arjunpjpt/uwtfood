package com.example.terryyu.uwtfood;

public class Order {

    static final int SIZE = 5;

    Item[] myItems;

    public Order() {
        myItems = new Item[SIZE];
    }

    public void addItem(Item theItem) {
        for(int i = 0; i<SIZE; i++) {
           if( myItems[i]== null)  {
               myItems[i] = theItem;
               return;
           }
        }
    }

    public void printOrder() {
        for(int i=0; i<SIZE; i++) {
            if( myItems[i] != null)  {
                System.out.println(myItems[i].myName + " " + myItems[i].myPrice );
            } else {
                break;
            }
        }
    }
}
