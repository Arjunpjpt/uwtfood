package com.example.terryyu.uwtfood;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class ChineseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chinese);


        final Order currentOrder = new Order();

        Button cartBtn = (Button) findViewById(R.id.cartBtnChinese);


        ImageButton kpChicken  = (ImageButton) findViewById(R.id.kpcImageButton);

        kpChicken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String theItemName = "kung pao Chicken";
                double theItemPrice = 9.99;

                Item theItem = new Item(theItemName, theItemPrice);

                currentOrder.addItem(theItem);

                currentOrder.printOrder();
            }
        });











        cartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent (getApplicationContext(), FourthActivity.class);
                startActivity(startIntent);
            }
        });
    }
}
