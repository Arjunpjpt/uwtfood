package com.example.terryyu.uwtfood;

public class Item {

    public String myName;

    public double myPrice;

    public Item(String theName, double thePrice){
        myName = theName;
        myPrice = thePrice;
    }
}
