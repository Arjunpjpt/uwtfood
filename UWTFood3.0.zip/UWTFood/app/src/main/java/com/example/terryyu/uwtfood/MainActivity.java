package com.example.terryyu.uwtfood;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final HashMap<String, String> myAccounts = new HashMap<String, String>();
        myAccounts.put("Arjun","123");
        myAccounts.put("Ruitao","123");
        myAccounts.put("Zebin","123");






        Button firstBtn = (Button) findViewById(R.id.loginBtn);
        firstBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                EditText theUserName = (EditText) findViewById(R.id.userNameEditText);
                EditText theUserPassword = (EditText) findViewById(R.id.userPaswwordEditText);
                TextView theError = (TextView) findViewById(R.id.errorTextView);

                String theAccount = theUserName.getText().toString();
                String thePassword = theUserPassword.getText().toString();

                if(myAccounts.containsKey(theAccount) && myAccounts.get(theAccount).equals(thePassword)) {
                    Intent startIntent = new Intent (getApplicationContext(), SecondActivity.class);
                    startActivity(startIntent);
                } else {
                    System.out.println("Your are in else");
                    theError.setText("What the fuck did you put in?");
                }





            }
        });
    }
}
