package com.example.terryyu.uwtfood;

public class Customer {
}
